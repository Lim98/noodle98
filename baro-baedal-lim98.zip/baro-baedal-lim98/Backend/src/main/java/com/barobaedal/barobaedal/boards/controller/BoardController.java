package com.barobaedal.barobaedal.boards.controller;

import com.barobaedal.barobaedal.boards.dto.BoardDto;
import com.barobaedal.barobaedal.boards.service.BoardService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.RequiredArgsConstructor;
import java.util.List;
import com.barobaedal.barobaedal.common.JwtUtil;

@RestController
@RequestMapping("/api/board")
@RequiredArgsConstructor
public class BoardController {

    private final BoardService boardService;
    private final JwtUtil jwtUtil;

    private String getUserid(HttpServletRequest request){
        return (String) request.getAttribute("userid");
    }

    private String getRole(HttpServletRequest request) {
        String userid = getUserid(request);
        if (userid == null) {
            return null;
        }
        return boardService.getRoleByUserid(userid);
    }

    private String getRoleByToken(String userid) {
        if (userid == null) {
            return null;
        }
        return boardService.getRoleByUserid(userid);
    }

    private Integer getMemberId(HttpServletRequest request) {
        Object id = request.getAttribute("memberId");
        if (id instanceof Integer) {
            return (Integer) id;
        } else if (id instanceof String) {
            return Integer.parseInt((String) id);
        }
        return null;
    }

    @GetMapping
    public ResponseEntity<?> getBoards(@RequestHeader(value = "Authorization", required = false) String authHeader,
                                       @RequestParam String category, HttpServletRequest request) {
        System.out.println(category);
        System.out.println("request : "+request);

        String userid = jwtUtil.auth(authHeader);

        System.out.println("[getBoards]userid : " + userid);

        if (userid == null) {
            return ResponseEntity.status(401).body("로그인이 필요합니다.");
        }
        //String role = getRole(request);
        String role = getRoleByToken(userid);
        System.out.println("[getBoards] role : " + role);

        List<BoardDto> boards = boardService.getBoardsByCategory(category, role, userid);
        return ResponseEntity.ok(boards);
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getBoard(@RequestHeader(value = "Authorization", required = false) String authHeader,
            @PathVariable Integer id, HttpServletRequest request) {

        String userid = jwtUtil.auth(authHeader);
        if (userid == null ){
            return ResponseEntity.status(401).body("로그인이 필요합니다.");
        }
        BoardDto board = boardService.getBoardById(id);
        if (board == null) {
            return ResponseEntity.notFound().build();
        }
//        String role = getRole(request);
        String role = getRoleByToken(userid);
        System.out.println("[getBoard] role : " + role);


        if(!boardService.canRead(board, userid, role)){
            return ResponseEntity.status(403).body("권한이 없습니다.");
        }
        return ResponseEntity.ok(board);
    }

    // 문의사항, 공지사항 게시판 글쓰기
    @PostMapping
    public ResponseEntity<?> createBoard(@RequestHeader(value = "Authorization", required = false) String authHeader,
            @RequestBody BoardDto dto, HttpServletRequest request) {
        //String userid = getUserid(request);
        String userid = jwtUtil.auth(authHeader);

        if (userid == null){
            return ResponseEntity.status(401).body("로그인이 필요합니다.");
        }
        String role = getRole(request);
        Integer memberId = getMemberId(request);
        if (memberId == null) {
            // 예외적으로 memberId가 없으면 찬찬히 userid로 DB에서 조회
            memberId = boardService.getMemberIdByUserid(userid);
        }

        dto.setMemberId(memberId);
        try {
            BoardDto board = boardService.createBoard(dto, role, userid);
            return ResponseEntity.ok(board);
        } catch (SecurityException | IllegalArgumentException e) {
            return ResponseEntity.status(403).body(e.getMessage());
        }
    }

    // 게시글 수정
    @PostMapping("/update/{id}")
    public ResponseEntity<?> updateBoard(@PathVariable Integer id, @RequestBody BoardDto dto, HttpServletRequest request) {
        String userid = getUserid(request);
        System.out.println(dto);
        if (userid == null) {
            return ResponseEntity.status(401).body("로그인이 필요합니다.");
        }
        String role = getRole(request);
        dto.setId(id);
        dto.setMemberId(getMemberId(request));
        try {
            BoardDto updated = boardService.updateBoard(dto, role, userid);
            return ResponseEntity.ok(updated);
        } catch (SecurityException | IllegalArgumentException e) {
            return ResponseEntity.status(403).body(e.getMessage());
        }
    }

    @GetMapping("/delete/{id}")
    public ResponseEntity<?> deleteBoard(@PathVariable Integer id, HttpServletRequest request) {
        String userid = getUserid(request);
        if (userid == null) {
            return ResponseEntity.status(401).body("로그인이 필요합니다.");
        }

        String role = getRole(request);
        try {
            boardService.deleteBoard(id, role, userid);
            return ResponseEntity.ok("삭제되었습니다.");
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body(e.getMessage());
        }
    }
}
