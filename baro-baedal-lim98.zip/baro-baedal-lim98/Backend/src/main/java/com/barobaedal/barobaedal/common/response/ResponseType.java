package com.barobaedal.barobaedal.common.response;

public enum ResponseType {
    SUCCESS, FAIL, ERROR
}