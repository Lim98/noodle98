package com.barobaedal.barobaedal.members.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PointDto {
    private int point;
}
