package com.barobaedal.barobaedal.orders.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SalesRequest {
    private int storeId;
    private String month;
}
