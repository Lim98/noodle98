package com.barobaedal.barobaedal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarobaedalApplicationTests {

	@Test
	void contextLoads() {
	}

}
