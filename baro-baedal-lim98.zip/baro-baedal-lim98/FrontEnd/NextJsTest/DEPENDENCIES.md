# 프로젝트 의존성 정리

## 핵심 의존성

### 프레임워크 & 런타임
- `next` (v15.5.6) - Next.js 프레임워크
- `react` (v18.3.1) - React 라이브러리
- `react-dom` (v18.3.1) - React DOM
- `typescript` (v5) - TypeScript 지원

### UI 컴포넌트 & 스타일링
- `@radix-ui/*` - 접근성이 고려된 UI 컴포넌트 라이브러리
  - 주요 컴포넌트: accordion, alert-dialog, avatar, dialog, dropdown-menu 등
- `tailwindcss` (v4.1.9) - CSS 프레임워크
- `tailwind-merge` - Tailwind 클래스 병합 유틸리티
- `tailwindcss-animate` - Tailwind 애니메이션
- `class-variance-authority` - 컴포넌트 스타일 변형 관리
- `clsx` - 조건부 클래스네임 유틸리티

### 폼 & 데이터 관리
- `react-hook-form` (v7.60.0) - 폼 상태 관리
- `@hookform/resolvers` - 폼 유효성 검사
- `zod` - 타입 검증 라이브러리
- `swr` - 데이터 페칭 라이브러리

### UI/UX 개선
- `framer-motion` - 애니메이션
- `sonner` - 토스트 알림
- `next-themes` - 테마 관리
- `embla-carousel-react` - 캐러셀/슬라이더
- `react-day-picker` - 날짜 선택 컴포넌트
- `date-fns` - 날짜 포맷팅 및 조작
- `recharts` - 차트 라이브러리
- `lucide-react` - 아이콘

### 개발 도구
- `@types/node` - Node.js 타입 정의
- `@types/react` - React 타입 정의
- `@types/react-dom` - React DOM 타입 정의
- `postcss` - CSS 전처리기
- `autoprefixer` - CSS 벤더 프리픽스 자동화

## 프로젝트 특징

1. **모던 웹 프레임워크**
   - Next.js 15.5.6을 사용한 React 기반 프레임워크
   - TypeScript로 타입 안정성 확보

2. **UI/UX**
   - Radix UI를 사용한 접근성 높은 컴포넌트
   - Tailwind CSS로 효율적인 스타일링
   - 다크모드 지원
   - 애니메이션 및 인터랙션

3. **개발 경험**
   - TypeScript 지원
   - 강력한 폼 관리 도구
   - 데이터 페칭 최적화
   - 자동화된 스타일링 도구

## 권장 추가 의존성

1. **테스트**
   - Jest
   - React Testing Library
   - Cypress (E2E 테스트)

2. **코드 품질**
   - ESLint
   - Prettier
   - Husky (git hooks)

3. **성능 모니터링**
   - next-bundle-analyzer
   - web-vitals