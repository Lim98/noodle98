"use client"
import MemberRegisterPage from "@/components/member-register-page"

export default function RegisterRoute() {
  return <MemberRegisterPage />
}
