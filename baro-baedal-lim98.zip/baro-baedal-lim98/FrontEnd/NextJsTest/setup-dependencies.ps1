# PowerShell 스크립트로 의존성 설치

Write-Host "Next.js 프로젝트 의존성 설치를 시작합니다..." -ForegroundColor Green

# 핵심 의존성 설치
$coreDependencies = @(
    "next@15.5.6",
    "react@18.3.1",
    "react-dom@18.3.1",
    "@vercel/analytics@latest",
    "swr@latest"
)

# UI 컴포넌트
$uiDependencies = @(
    "@radix-ui/react-accordion@1.2.2",
    "@radix-ui/react-alert-dialog@1.1.4",
    "@radix-ui/react-aspect-ratio@1.1.1",
    "@radix-ui/react-avatar@1.1.2",
    "@radix-ui/react-checkbox@1.1.3",
    "@radix-ui/react-collapsible@1.1.2",
    "@radix-ui/react-context-menu@2.2.4",
    "@radix-ui/react-dialog@1.1.4",
    "@radix-ui/react-dropdown-menu@2.1.4",
    "@radix-ui/react-hover-card@1.1.4",
    "@radix-ui/react-label@2.1.1",
    "@radix-ui/react-menubar@1.1.4",
    "@radix-ui/react-navigation-menu@1.2.3",
    "@radix-ui/react-popover@1.1.4",
    "@radix-ui/react-progress@1.1.1",
    "@radix-ui/react-radio-group@1.2.2",
    "@radix-ui/react-scroll-area@1.2.2",
    "@radix-ui/react-select@2.1.4",
    "@radix-ui/react-separator@1.1.1",
    "@radix-ui/react-slider@1.2.2",
    "@radix-ui/react-slot@1.1.1",
    "@radix-ui/react-switch@1.1.2",
    "@radix-ui/react-tabs@1.1.2",
    "@radix-ui/react-toast@1.2.4",
    "@radix-ui/react-toggle@1.1.1",
    "@radix-ui/react-toggle-group@1.1.1",
    "@radix-ui/react-tooltip@1.1.6"
)

# 스타일링 의존성
$stylingDependencies = @(
    "tailwindcss@4.1.9",
    "tailwind-merge@2.5.5",
    "tailwindcss-animate@1.0.7",
    "class-variance-authority@0.7.1",
    "clsx@2.1.1"
)

# 폼 & 데이터 관리
$formDataDependencies = @(
    "react-hook-form@7.60.0",
    "@hookform/resolvers@3.10.0",
    "zod@3.25.76"
)

# UI/UX 개선
$uiuxDependencies = @(
    "framer-motion@12.23.24",
    "sonner@1.7.4",
    "next-themes@0.4.6",
    "embla-carousel-react@8.5.1",
    "react-day-picker@9.8.0",
    "date-fns@4.1.0",
    "recharts@2.15.4",
    "lucide-react@0.454.0",
    "vaul@0.9.9"
)

# 개발 도구
$devDependencies = @(
    "--save-dev typescript@5",
    "--save-dev @types/node@22",
    "--save-dev @types/react@19",
    "--save-dev @types/react-dom@19",
    "--save-dev postcss@8.5",
    "--save-dev autoprefixer@10.4.20",
    "--save-dev @tailwindcss/postcss@4.1.9",
    "--save-dev tw-animate-css@1.3.3"
)

Write-Host "핵심 의존성 설치 중..." -ForegroundColor Yellow
npm install $coreDependencies

Write-Host "UI 컴포넌트 설치 중..." -ForegroundColor Yellow
npm install $uiDependencies

Write-Host "스타일링 의존성 설치 중..." -ForegroundColor Yellow
npm install $stylingDependencies

Write-Host "폼 & 데이터 관리 의존성 설치 중..." -ForegroundColor Yellow
npm install $formDataDependencies

Write-Host "UI/UX 개선 의존성 설치 중..." -ForegroundColor Yellow
npm install $uiuxDependencies

Write-Host "개발 도구 설치 중..." -ForegroundColor Yellow
npm install $devDependencies

# 권장 추가 의존성 (선택적)
$recommendedDependencies = @(
    "--save-dev jest@latest",
    "--save-dev @testing-library/react@latest",
    "--save-dev @testing-library/jest-dom@latest",
    "--save-dev cypress@latest",
    "--save-dev eslint@latest",
    "--save-dev prettier@latest",
    "--save-dev husky@latest",
    "--save-dev @next/bundle-analyzer@latest",
    "web-vitals@latest"
)

$installRecommended = Read-Host "권장 추가 의존성을 설치하시겠습니까? (y/n)"
if ($installRecommended -eq "y") {
    Write-Host "권장 추가 의존성 설치 중..." -ForegroundColor Yellow
    npm install $recommendedDependencies
}

Write-Host "의존성 설치가 완료되었습니다!" -ForegroundColor Green
Write-Host "package.json 파일을 확인하여 모든 의존성이 올바르게 설치되었는지 확인하세요." -ForegroundColor Cyan