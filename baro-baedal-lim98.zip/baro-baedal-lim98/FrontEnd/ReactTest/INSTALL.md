
## 🚀 설치 과정

### 1단계: Node.js 설치 확인
```bash
# Node.js 버전 확인
node --version

# npm 버전 확인
npm --version
```

**Node.js가 설치되어 있지 않은 경우:**
- [Node.js 공식 웹사이트](https://nodejs.org/)에서 LTS 버전 다운로드
- 설치 후 터미널을 재시작

### 2단계: 프로젝트 클론
```bash
# 프로젝트 클론 (이미 클론된 경우 생략)
git clone <repository-url>
cd baro-baedal/FrontEnd/ReactTest
```

### 3단계: 의존성 설치
```bash
# npm 캐시 정리 (선택사항)
npm cache clean --force

# 의존성 설치
npm install
```

### 4단계: 환경 변수 설정
```bash
# 환경 변수 파일 생성
cp env.example .env
```

### 5단계: 개발 서버 실행
```bash
# 개발 서버 시작
npm run dev
```

## 🔧 설치 문제 해결

### 문제 1: npm install 실패
```bash
# 해결 방법 1: 캐시 정리 후 재설치
npm cache clean --force
rm -rf node_modules package-lock.json
npm install

# 해결 방법 2: npm 버전 업데이트
npm install -g npm@latest
npm install
```

### 문제 2: Node.js 버전 호환성
```bash
# Node.js 버전 확인
node --version

# 18.0.0 미만인 경우 업그레이드 필요
# nvm 사용 시
nvm install 18
nvm use 18
```

### 문제 3: 포트 충돌
```bash
# 다른 포트로 실행
npm run dev -- --port 3000

# 또는 환경 변수로 설정
PORT=3000 npm run dev
```

### 문제 4: 권한 오류 (Windows)
```bash
# 관리자 권한으로 실행
# 또는 npm 글로벌 설치 경로 변경
npm config set prefix ~/.npm-global
```

## 🧪 설치 확인

### 1. 개발 서버 실행 확인
```bash
npm run dev
```
- 브라우저에서 `http://localhost:5173` 접속 가능
- "바로배달" 메인 페이지가 표시됨

### 2. 빌드 테스트
```bash
npm run build
```
- `dist/` 폴더에 빌드 파일 생성 확인

### 3. 린팅 테스트
```bash
npm run lint
```
- ESLint 오류 없이 통과 확인

## 📦 의존성 정보

### 주요 의존성
- **React**: 19.1.1 - UI 라이브러리
- **Vite**: 7.1.7 - 빌드 도구
- **Tailwind CSS**: 4.1.15 - CSS 프레임워크

### 개발 의존성
- **ESLint**: 9.36.0 - 코드 린팅
- **TypeScript**: 타입 정의 파일들

## 🔄 업데이트

### 의존성 업데이트
```bash
# 보안 업데이트 확인
npm audit

# 의존성 업데이트
npm update

# 특정 패키지 업데이트
npm install package-name@latest
```

### 프로젝트 업데이트
```bash
# 최신 코드 가져오기
git pull origin main

# 의존성 재설치
npm install
```

## 🆘 추가 도움

### 일반적인 문제들
1. **메모리 부족**: Node.js 메모리 제한 증가
   ```bash
   export NODE_OPTIONS="--max-old-space-size=4096"
   ```

2. **네트워크 문제**: npm 레지스트리 변경
   ```bash
   npm config set registry https://registry.npmjs.org/
   ```

3. **캐시 문제**: npm 캐시 완전 정리
   ```bash
   npm cache clean --force
   rm -rf ~/.npm
   npm install
   ```

### 지원 요청
- GitHub Issues에 문제 보고
- 로그 파일과 함께 상세한 오류 메시지 포함
- 운영체제 및 Node.js 버전 정보 포함
