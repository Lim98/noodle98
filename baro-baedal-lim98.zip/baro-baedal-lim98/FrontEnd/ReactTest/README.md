# 바로배달 Frontend

바로배달 서비스의 React 기반 프론트엔드 애플리케이션입니다.

## 🚀 주요 기능

- **회원 관리**: 회원가입, 로그인, 로그아웃
- **회원정보 관리**: 회원정보 조회 및 수정
- **가게 등록**: 사장님을 위한 가게 등록 기능
- **반응형 디자인**: 모바일과 데스크톱 모두 지원

## 🛠 기술 스택

- **Frontend Framework**: React 19.1.1
- **Build Tool**: Vite 7.1.7
- **Styling**: Tailwind CSS 4.1.15
- **Linting**: ESLint 9.36.0
- **Package Manager**: npm

## 📋 사전 요구사항

- **Node.js**: 18.0.0 이상
- **npm**: 8.0.0 이상
- **백엔드 서버**: API 서버가 실행 중이어야 함

## 🚀 설치 및 실행

### 1. 의존성 설치
```bash
cd FrontEnd/ReactTest
npm install
```

### 2. 환경 변수 설정
`.env` 파일을 생성하고 다음 내용을 추가하세요:
```env
VITE_API_BASE_URL=http://localhost:8080
```

### 3. 개발 서버 실행
```bash
npm run dev
```

### 4. 브라우저에서 확인
- 개발 서버가 실행되면 `http://localhost:5173`에서 애플리케이션을 확인할 수 있습니다.

## 📁 프로젝트 구조

```
src/
├── pages/                 # 페이지 컴포넌트
│   ├── LoginPage.jsx      # 로그인 페이지
│   ├── MemberRegisterPage.jsx  # 회원가입 페이지
│   ├── MyInfoPage.jsx     # 회원정보 조회 페이지
│   ├── EditInfoPage.jsx   # 회원정보 수정 페이지
│   └── StoreCreatePage.jsx # 가게 등록 페이지
├── services/              # API 서비스
│   ├── memberService.js   # 회원 관련 API
│   └── storeService.js    # 가게 관련 API
├── utils/                 # 유틸리티 함수
│   └── authUtils.js       # 인증 관련 유틸리티
├── App.jsx               # 메인 앱 컴포넌트
└── main.jsx              # 앱 진입점
```

## 🔧 사용 가능한 스크립트

```bash
# 개발 서버 실행
npm run dev

# 프로덕션 빌드
npm run build

# 빌드 미리보기
npm run preview

# 린팅 검사
npm run lint
```

## 🌐 API 엔드포인트

### 회원 관련 API
- `POST /api/member/register` - 회원가입
- `POST /api/member/login` - 로그인
- `GET /api/member/logout` - 로그아웃
- `GET /api/member/info` - 회원정보 조회
- `POST /api/member/info` - 회원정보 수정

### 가게 관련 API
- `POST /api/store/register` - 가게 등록

## 🔐 인증 방식

- **토큰 기반 인증**: JWT 토큰을 사용한 인증
- **토큰 저장**: localStorage에 토큰 저장
- **자동 인증**: 페이지 새로고침 시 토큰 확인

## 🎨 UI/UX 특징

- **반응형 디자인**: Tailwind CSS를 사용한 모바일 우선 디자인
- **사용자 친화적**: 직관적인 네비게이션과 폼 디자인
- **접근성**: 키보드 네비게이션 및 스크린 리더 지원

## 🧪 개발 모드

개발 모드에서는 자동으로 가상 로그인 상태가 설정됩니다:
- 자동 로그인: `test001` 계정으로 로그인 상태
- Mock 토큰: `dev-token-12345`

## 🐛 문제 해결

### 1. API 연결 오류
- 백엔드 서버가 실행 중인지 확인
- `.env` 파일의 `VITE_API_BASE_URL` 설정 확인

### 2. 빌드 오류
```bash
# 의존성 재설치
rm -rf node_modules package-lock.json
npm install
```

### 3. 포트 충돌
```bash
# 다른 포트로 실행
npm run dev -- --port 3000
```

## 📝 개발 가이드

### 새 페이지 추가
1. `src/pages/` 디렉토리에 새 컴포넌트 생성
2. `src/App.jsx`의 `renderPage()` 함수에 라우팅 추가
3. 필요한 API 서비스 함수 추가

### API 서비스 추가
1. `src/services/` 디렉토리에 새 서비스 파일 생성
2. `authUtils.js`의 `getAuthHeaders()` 함수 활용
3. 에러 처리 및 인증 만료 처리 포함

## 🤝 기여하기

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 라이선스

이 프로젝트는 MIT 라이선스 하에 배포됩니다.

## 📞 지원

문제가 발생하거나 질문이 있으시면 이슈를 생성해 주세요.