import { useState, useEffect } from 'react'
import StoreCreatePage from './pages/StoreCreatePage'
import StoreEditPage from './pages/StoreEditPage'
import StoreManagePage from './pages/StoreManagePage'
import MemberRegisterPage from './pages/MemberRegisterPage'
import LoginPage from './pages/LoginPage'
import MyInfoPage from './pages/MyInfoPage'
import { isLoggedIn, getAuthInfo, clearAuthInfo } from './utils/authUtils'
import './App.css'

function App() {
  const [currentPage, setCurrentPage] = useState('home')
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userInfo, setUserInfo] = useState(null)
  const [selectedStoreId, setSelectedStoreId] = useState(null)

  // 컴포넌트 마운트 시 로그인 상태 확인
  useEffect(() => {
    const checkAuthStatus = () => {
      if (isLoggedIn()) {
        setIsAuthenticated(true)
        setUserInfo(getAuthInfo())
      } else {
        setIsAuthenticated(false)
        setUserInfo(null)
      }
    }
    
    checkAuthStatus()
    
    // 주기적으로 로그인 상태 확인 (토큰 만료 등)
    const interval = setInterval(checkAuthStatus, 30000) // 30초마다 확인
    
    return () => clearInterval(interval)
  }, [])

  // 로그아웃 처리
  const handleLogout = () => {
    clearAuthInfo()
    setIsAuthenticated(false)
    setUserInfo(null)
    setCurrentPage('home')
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'store':
        return <StoreCreatePage />
      case 'store-manage':
        return <StoreManagePage 
          onBack={() => setCurrentPage('home')}
          onEdit={(storeId) => {
            setSelectedStoreId(storeId)
            setCurrentPage('store-edit')
          }}
        />
      case 'store-edit':
        return <StoreEditPage 
          storeId={selectedStoreId}
          onBack={() => setCurrentPage('store-manage')}
          onSave={() => setCurrentPage('store-manage')}
        />
      case 'member':
        return <MemberRegisterPage />
      case 'login':
        return <LoginPage onPageChange={setCurrentPage} onLoginSuccess={() => {
          setIsAuthenticated(true)
          setUserInfo(getAuthInfo())
          setCurrentPage('home')
        }} />
      case 'my-info':
        return <MyInfoPage onPageChange={setCurrentPage} />
      default:
        return (
          <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
            <div className="text-center">
              <img 
                src="/logo_white.png" 
                alt="바로배달" 
                className="h-16 mb-8 mx-auto"
              />
              <div className="space-y-4">
                {!isAuthenticated ? (
                  <>
                    <button
                      onClick={() => setCurrentPage('login')}
                      className="block w-full max-w-xs mx-auto px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                    >
                      로그인
                    </button>
                    <button
                      onClick={() => setCurrentPage('member')}
                      className="block w-full max-w-xs mx-auto px-6 py-3 bg-gray-600 text-white rounded-md hover:bg-gray-700"
                    >
                      회원가입
                    </button>
                  </>
                ) : (
                  <div className="text-center">
                    <div className="mb-4">
                      <p className="text-lg mb-2">안녕하세요, {userInfo?.userid}님!</p>
                      <div className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-green-100 text-green-800">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                        로그인됨
                      </div>
                    </div>
                    <div className="space-y-3">
                      <button
                        onClick={() => setCurrentPage('my-info')}
                        className="block w-full max-w-xs mx-auto px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                      >
                        내 정보
                      </button>
                      <button
                        onClick={handleLogout}
                        className="block w-full max-w-xs mx-auto px-6 py-3 bg-red-600 text-white rounded-md hover:bg-red-700"
                      >
                        로그아웃
                      </button>
                    </div>
                  </div>
                )}
                <button
                  onClick={() => setCurrentPage('store')}
                  className="block w-full max-w-xs mx-auto px-6 py-3 bg-green-600 text-white rounded-md hover:bg-green-700"
                >
                  가게 등록
                </button>
                <button
                  onClick={() => setCurrentPage('store-manage')}
                  className="block w-full max-w-xs mx-auto px-6 py-3 bg-purple-600 text-white rounded-md hover:bg-purple-700"
                >
                  가게 관리
                </button>
              </div>
            </div>
          </div>
        )
    }
  }


  return (
    <div>
      {currentPage !== 'home' && (
        <nav className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex items-center">
                <button
                  onClick={() => setCurrentPage('home')}
                  className="text-xl font-bold text-gray-800 hover:text-blue-600"
                >
                  <img 
                    src="/logo_black.png" 
                    alt="바로배달" 
                    className="h-8"
                  />
                </button>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => setCurrentPage('home')}
                  className="text-gray-600 hover:text-gray-900"
                >
                  홈으로
                </button>
              </div>
            </div>
          </div>
        </nav>
      )}
      {renderPage()}
    </div>
  )
}

export default App
