import { useState, useEffect } from 'react'
import { memberService } from '../services/memberService'
import { isLoggedIn } from '../utils/authUtils'

const MyInfoPage = ({ onPageChange }) => {
  const [userInfo, setUserInfo] = useState(null)
  const [isLoading, setIsLoading] = useState(true)
  const [isEditing, setIsEditing] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [formData, setFormData] = useState({
    name: '',
    birth: '',
    phone: '',
    email: '',
    address: ''
  })

  useEffect(() => {
    // 로그인 상태 확인
    if (!isLoggedIn()) {
      setIsLoading(false)
      setError('로그인이 필요합니다. 로그인 후 다시 시도해주세요.')
      return
    }
    loadUserInfo()
  }, [])

  const loadUserInfo = async () => {
    try {
      setIsLoading(true)
      setError('')
      
      const response = await memberService.getMyInfo()
      
      if (response.responseType === 'SUCCESS') {
        setUserInfo(response.data)
        // 폼 데이터도 함께 설정
        setFormData({
          name: response.data.name || '',
          birth: response.data.birth || '',
          phone: response.data.phone || '',
          email: response.data.email || '',
          address: response.data.address || ''
        })
      } else {
        setError(response.message || '회원정보 조회에 실패했습니다.')
      }
    } catch (error) {
      console.error('회원정보 조회 오류:', error)
      setError(error.message || '회원정보 조회 중 오류가 발생했습니다.')
    } finally {
      setIsLoading(false)
    }
  }

  const formatDate = (dateString) => {
    if (!dateString) return '-'
    return new Date(dateString).toLocaleDateString('ko-KR')
  }

  const formatPhone = (phone) => {
    if (!phone) return '-'
    return phone
  }

  const formatAddress = (address) => {
    if (!address) return '-'
    return address
  }

  // 수정 모드 토글
  const toggleEdit = () => {
    setIsEditing(!isEditing)
    setError('')
    setSuccess('')
  }

  // 폼 데이터 변경
  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
    if (error) setError('')
    if (success) setSuccess('')
  }

  // 정보 수정 저장
  const handleSave = async () => {
    // 입력값 검증
    if (!formData.name.trim()) {
      setError('이름을 입력해주세요.')
      return
    }
    if (!formData.phone.trim()) {
      setError('전화번호를 입력해주세요.')
      return
    }
    if (!formData.email.trim()) {
      setError('이메일을 입력해주세요.')
      return
    }

    // 이메일 형식 검증
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(formData.email)) {
      setError('올바른 이메일 형식을 입력해주세요.')
      return
    }

    setIsSaving(true)
    setError('')
    setSuccess('')

    try {
      const response = await memberService.updateMyInfo(formData)
      
      if (response.responseType === 'SUCCESS') {
        setSuccess('회원정보가 성공적으로 수정되었습니다.')
        
        // 토큰이 새로 발급된 경우 저장
        if (response.data?.token) {
          localStorage.setItem('token', response.data.token)
        }
        
        // 사용자 정보 업데이트
        setUserInfo(prev => ({
          ...prev,
          ...formData
        }))
        
        // 2초 후 수정 모드 종료
        setTimeout(() => {
          setIsEditing(false)
          setSuccess('')
        }, 2000)
      } else {
        setError(response.message || '회원정보 수정에 실패했습니다.')
      }
    } catch (error) {
      console.error('회원정보 수정 오류:', error)
      setError(error.message || '회원정보 수정 중 오류가 발생했습니다.')
    } finally {
      setIsSaving(false)
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">회원정보를 불러오는 중...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
        {/* Header */}
        <header className="sticky top-0 z-10 backdrop-blur supports-[backdrop-filter]:bg-white/70 bg-white/90 border-b">
          <div className="mx-auto max-w-4xl px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => onPageChange('home')}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <div>
                <h1 className="text-lg font-semibold">내 정보</h1>
                <p className="text-xs text-slate-500">회원 정보를 확인하고 수정하세요</p>
              </div>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-4xl px-4 py-8">
          <div className="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-200">
              <h2 className="text-xl font-semibold text-slate-900">내 정보</h2>
              <p className="mt-1 text-sm text-slate-600">회원 정보를 확인하려면 로그인이 필요합니다</p>
            </div>
            
            <div className="p-8 text-center">
              <div className="text-red-500 text-6xl mb-4">🔒</div>
              <h3 className="text-xl font-semibold text-slate-800 mb-2">로그인이 필요합니다</h3>
              <p className="text-slate-600 mb-6">{error}</p>
              
              <div className="flex flex-col sm:flex-row gap-3 justify-center">
                <button
                  onClick={() => onPageChange('login')}
                  className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  로그인하기
                </button>
                <button
                  onClick={() => onPageChange('home')}
                  className="px-6 py-3 border border-slate-300 text-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
                >
                  홈으로 돌아가기
                </button>
              </div>
            </div>
          </div>
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-10 backdrop-blur supports-[backdrop-filter]:bg-white/70 bg-white/90 border-b">
        <div className="mx-auto max-w-4xl px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => onPageChange('home')}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div>
              <h1 className="text-lg font-semibold">내 정보</h1>
              <p className="text-xs text-slate-500">회원 정보를 확인하고 수정하세요</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-sm text-slate-600">안녕하세요,</span>
            <span className="font-medium text-slate-800">{userInfo?.userid}님</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-8">
        <div className="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-200">
            <h2 className="text-xl font-semibold text-slate-900">회원정보</h2>
            <p className="mt-1 text-sm text-slate-600">
              {isEditing ? '회원정보를 수정하세요' : '내 회원정보를 확인하세요'}
            </p>
          </div>

          <div className="px-6 py-6">
            {isEditing ? (
              // 수정 모드
              <form onSubmit={(e) => { e.preventDefault(); handleSave(); }}>
                <div className="space-y-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                      이름 *
                    </label>
                    <input
                      id="name"
                      name="name"
                      type="text"
                      required
                      value={formData.name}
                      onChange={handleChange}
                      className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="이름을 입력하세요"
                    />
                  </div>

                  <div>
                    <label htmlFor="birth" className="block text-sm font-medium text-gray-700">
                      생년월일
                    </label>
                    <input
                      id="birth"
                      name="birth"
                      type="date"
                      value={formData.birth}
                      onChange={handleChange}
                      className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    />
                  </div>

                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700">
                      전화번호 *
                    </label>
                    <input
                      id="phone"
                      name="phone"
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={handleChange}
                      className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="010-1234-5678"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      이메일 *
                    </label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={handleChange}
                      className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="example@email.com"
                    />
                  </div>

                  <div>
                    <label htmlFor="address" className="block text-sm font-medium text-gray-700">
                      주소
                    </label>
                    <textarea
                      id="address"
                      name="address"
                      rows={3}
                      value={formData.address}
                      onChange={handleChange}
                      className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="주소를 입력하세요"
                    />
                  </div>
                </div>

                {error && (
                  <div className="mt-4 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md text-sm">
                    {error}
                  </div>
                )}

                {success && (
                  <div className="mt-4 bg-green-50 border border-green-200 text-green-600 px-4 py-3 rounded-md text-sm">
                    {success}
                  </div>
                )}

                <div className="mt-8 flex justify-end space-x-3">
                  <button
                    type="button"
                    onClick={toggleEdit}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 bg-white hover:bg-gray-50"
                  >
                    취소
                  </button>
                  <button
                    type="submit"
                    disabled={isSaving}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSaving ? (
                      <div className="flex items-center">
                        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        저장 중...
                      </div>
                    ) : (
                      '저장'
                    )}
                  </button>
                </div>
              </form>
            ) : (
              // 조회 모드 - 목록 형태로 표시
              <div className="space-y-6">
                {/* 기본 정보 섹션 */}
                <div className="bg-slate-50 rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                    <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    기본 정보
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center justify-between py-3 border-b border-slate-200">
                      <span className="text-sm font-medium text-slate-600">아이디</span>
                      <span className="text-sm text-slate-800 font-mono">{userInfo?.userid || '-'}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-200">
                      <span className="text-sm font-medium text-slate-600">이름</span>
                      <span className="text-sm text-slate-800">{userInfo?.name || '-'}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-200">
                      <span className="text-sm font-medium text-slate-600">생년월일</span>
                      <span className="text-sm text-slate-800">{formatDate(userInfo?.birth)}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-200">
                      <span className="text-sm font-medium text-slate-600">권한</span>
                      <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                        userInfo?.role === 'OWNER' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {userInfo?.role === 'OWNER' ? '사장님' : '일반회원'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* 연락처 정보 섹션 */}
                <div className="bg-slate-50 rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                    <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                    </svg>
                    연락처 정보
                  </h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between py-3 border-b border-slate-200">
                      <span className="text-sm font-medium text-slate-600">전화번호</span>
                      <span className="text-sm text-slate-800">{formatPhone(userInfo?.phone)}</span>
                    </div>
                    <div className="flex items-center justify-between py-3 border-b border-slate-200">
                      <span className="text-sm font-medium text-slate-600">이메일</span>
                      <span className="text-sm text-slate-800">{userInfo?.email || '-'}</span>
                    </div>
                    <div className="flex items-start justify-between py-3">
                      <span className="text-sm font-medium text-slate-600">주소</span>
                      <span className="text-sm text-slate-800 text-right max-w-xs">{formatAddress(userInfo?.address)}</span>
                    </div>
                  </div>
                </div>

                {/* 계정 정보 섹션 */}
                <div className="bg-slate-50 rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-slate-800 mb-4 flex items-center gap-2">
                    <svg className="w-5 h-5 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    계정 정보
                  </h3>
                  <div className="flex items-center justify-between py-3 border-b border-slate-200">
                    <span className="text-sm font-medium text-slate-600">가입일</span>
                    <span className="text-sm text-slate-800">{userInfo?.created_at || '-'}</span>
                  </div>
                </div>

                {/* 액션 버튼 */}
                <div className="flex justify-end space-x-3 pt-6 border-t border-slate-200">
                  <button
                    onClick={() => onPageChange('home')}
                    className="px-4 py-2 border border-slate-300 rounded-lg text-slate-700 bg-white hover:bg-slate-50 transition-colors"
                  >
                    홈으로
                  </button>
                  <button
                    onClick={toggleEdit}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    정보 수정
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
    </div>
  )
}

export default MyInfoPage
