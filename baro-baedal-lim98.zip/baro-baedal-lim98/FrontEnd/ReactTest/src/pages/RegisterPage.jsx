import { useState } from 'react';
import './RegisterPage.css';  // 스타일 import

function RegisterPage() {
    const [formData, setFormData] = useState({
        userid: '',
        userpw: '',
        name: '',
        birth: '',
        phone: '',
        email: '',
        address: '',
        role: 'USER'
    });

    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
        setError('');
    };

    const handleSubmit = async () => {
        if (!formData.userid || !formData.userpw || !formData.name || !formData.birth ||
            !formData.phone || !formData.email || !formData.address) {
            setError('모든 필드를 입력해주세요.');
            return;
        }

        setLoading(true);
        setError('');

        try {
            const now = new Date();
            const created_at = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

            const response = await fetch('/api/member/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    ...formData,
                    created_at
                })
            });

            const data = await response.json();

            if (data.responseType === 'SUCCESS') {
                alert(data.message);
                console.log('회원가입 성공:', data);
                // 로그인 페이지로 이동 등 추가 작업 가능
            } else {
                setError(data.message || '회원가입에 실패했습니다.');
            }
        } catch (err) {
            setError('서버와의 통신에 실패했습니다.');
            console.error('Register error:', err);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="register-container">
            <div className="register-card">
                <div className="register-header">
                    <h1 className="register-title">회원가입</h1>
                    <p className="register-subtitle">새로운 계정을 만드세요</p>
                </div>

                <div className="form-container">
                    <div className="form-group">
                        <label htmlFor="userid" className="form-label">아이디 *</label>
                        <input
                            type="text"
                            id="userid"
                            name="userid"
                            value={formData.userid}
                            onChange={handleChange}
                            className="form-input"
                            placeholder="아이디를 입력하세요"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="userpw" className="form-label">비밀번호 *</label>
                        <input
                            type="password"
                            id="userpw"
                            name="userpw"
                            value={formData.userpw}
                            onChange={handleChange}
                            className="form-input"
                            placeholder="비밀번호를 입력하세요"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="name" className="form-label">이름 *</label>
                        <input
                            type="text"
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleChange}
                            className="form-input"
                            placeholder="이름을 입력하세요"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="birth" className="form-label">생년월일 *</label>
                        <input
                            type="date"
                            id="birth"
                            name="birth"
                            value={formData.birth}
                            onChange={handleChange}
                            className="form-input"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="phone" className="form-label">전화번호 *</label>
                        <input
                            type="tel"
                            id="phone"
                            name="phone"
                            value={formData.phone}
                            onChange={handleChange}
                            className="form-input"
                            placeholder="010-1234-5678"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="email" className="form-label">이메일 *</label>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            value={formData.email}
                            onChange={handleChange}
                            className="form-input"
                            placeholder="test@test.com"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="address" className="form-label">주소 *</label>
                        <input
                            type="text"
                            id="address"
                            name="address"
                            value={formData.address}
                            onChange={handleChange}
                            className="form-input"
                            placeholder="서울특별시 중구 ~~"
                        />
                    </div>

                    <div className="form-group">
                        <label htmlFor="role" className="form-label">회원 구분 *</label>
                        <select
                            id="role"
                            name="role"
                            value={formData.role}
                            onChange={handleChange}
                            className="form-input"
                        >
                            <option value="USER">일반 사용자</option>
                            <option value="OWNER">점주</option>
                        </select>
                    </div>

                    {error && (
                        <div className="error-message">
                            {error}
                        </div>
                    )}

                    <button
                        onClick={handleSubmit}
                        disabled={loading}
                        className="register-button"
                    >
                        {loading ? '회원가입 중...' : '회원가입'}
                    </button>
                </div>
            </div>
        </div>
    );
}

export default RegisterPage;
