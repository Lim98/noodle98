import React, { useMemo, useState } from "react";
import { storeService } from "../services/storeService";

export default function StoreCreatePage() {
  const [form, setForm] = useState({
    name: "",
    category: "중국집",
    phone: "",
    address: "",
    opentime: "09:00",
    endtime: "23:00",
  });
  const [logoFile, setLogoFile] = useState(null);
  const [logoPreview, setLogoPreview] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null); // {type: 'SUCCESS'|'FAIL', message, data}
  const [errors, setErrors] = useState({});

  const categories = [
    "한식",
    "일식",
    "중식",
    "분식",
    "양식",
    "치킨",
    "피자",
    "카페/디저트",
  ];

  function validate(values) {
    const e = {};
    if (!values.name.trim()) e.name = "가게명을 입력해주세요.";
    if (!values.category) e.category = "카테고리를 선택해주세요.";
    if (!values.phone.trim()) e.phone = "연락처를 입력해주세요.";

    const phoneClean = values.phone.replace(/[-\s]/g, "");
    if (!/^01[016789][0-9]{7,8}$/.test(phoneClean)) {
      e.phone = "휴대폰 번호 형식이 올바르지 않습니다.";
    }
    if (!values.address.trim()) e.address = "주소를 입력해주세요.";
    if (!values.opentime) e.opentime = "오픈 시간을 설정하세요.";
    if (!values.endtime) e.endtime = "마감 시간을 설정하세요.";

    if (values.opentime && values.endtime) {
      const [oh, om] = values.opentime.split(":").map(Number);
      const [eh, em] = values.endtime.split(":").map(Number);
      const o = oh * 60 + om;
      const d = eh * 60 + em;
      if (o !== d && d < o) {
        e.endtime = "마감이 오픈보다 이른 경우 자정 넘김 영업인지 확인하세요.";
      }
    }
    return e;
  }

  const handleChange = (e) => {
    const { name, value } = e.target;

    // Small UX nicety: auto-format phone as 010-1234-5678 while typing
    if (name === "phone") {
      const digits = value.replace(/\D/g, "");
      let formatted = digits;
      if (digits.length > 3 && digits.length <= 7) {
        formatted = `${digits.slice(0, 3)}-${digits.slice(3)}`;
      } else if (digits.length > 7) {
        formatted = `${digits.slice(0, 3)}-${digits.slice(3, 7)}-${digits.slice(7, 11)}`;
      }
      setForm((prev) => ({ ...prev, [name]: formatted }));
      return;
    }

    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // 파일 크기 체크 (5MB 제한)
      if (file.size > 5 * 1024 * 1024) {
        alert('파일 크기는 5MB 이하여야 합니다.');
        return;
      }
      
      // 이미지 파일 타입 체크
      if (!file.type.startsWith('image/')) {
        alert('이미지 파일만 업로드 가능합니다.');
        return;
      }

      setLogoFile(file);
      
      // 미리보기 생성
      const reader = new FileReader();
      reader.onload = (e) => {
        setLogoPreview(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogoRemove = () => {
    setLogoFile(null);
    setLogoPreview(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const v = validate(form);
    setErrors(v);
    if (Object.keys(v).length > 0) return;

    setLoading(true);
    setResult(null);

    try {
      // 시간 정보를 분리하여 API 요청 형태로 변환
      const [openH, openM] = form.opentime.split(':').map(Number);
      const [closedH, closedM] = form.endtime.split(':').map(Number);
      
      const data = await storeService.createStore({
        name: form.name,
        category: form.category,
        phone: form.phone,
        address: form.address,
        openH: openH,
        openM: openM,
        closedH: closedH,
        closedM: closedM,
        createdAt: new Date().toISOString().split('T')[0] // 현재 날짜를 YYYY-MM-DD 형태로
      });

      setResult({
        type: data.responseType || "SUCCESS",
        message: data.message || "가게가 성공적으로 등록되었습니다.",
        data: data.data,
      });

      if (data?.data?.token) {
        localStorage.setItem("authToken", data.data.token);
      }
    } catch (err) {
      setResult({ type: "FAIL", message: err.message || "네트워크 오류가 발생했습니다." });
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setForm({ name: "", category: "중국집", phone: "", address: "", opentime: "09:00", endtime: "23:00" });
    setLogoFile(null);
    setLogoPreview(null);
    setErrors({});
    setResult(null);
  };

  const openDuration = useMemo(() => {
    if (!form.opentime || !form.endtime) return "—";
    const [oh, om] = form.opentime.split(":").map(Number);
    const [eh, em] = form.endtime.split(":").map(Number);
    let start = oh * 60 + om;
    let end = eh * 60 + em;
    if (end < start) end += 24 * 60; // cross midnight
    const h = Math.floor((end - start) / 60);
    const m = (end - start) % 60;
    return `${h}시간 ${m ? m + "분" : ""}`.trim();
  }, [form.opentime, form.endtime]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Top bar */}
      <header className="sticky top-0 z-10 backdrop-blur supports-[backdrop-filter]:bg-white/70 bg-white/90 border-b">
        <div className="mx-auto max-w-6xl px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-blue-600 grid place-items-center text-white font-bold">店</div>
            <div>
              <h1 className="text-lg font-semibold">가게 등록</h1>
              <p className="text-xs text-slate-500">필수 정보를 입력하고 등록 버튼을 누르세요.</p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-2 text-xs text-slate-500">
            <span className="px-2 py-1 rounded bg-slate-100">Vite</span>
            <span className="px-2 py-1 rounded bg-slate-100">React</span>
            <span className="px-2 py-1 rounded bg-slate-100">Tailwind</span>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 py-8">
        {/* Layout: Form (2) + Preview (1) */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          <section className="md:col-span-2">
            <div className="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200">
              <div className="border-b px-6 py-4">
                <h2 className="font-semibold">기본 정보</h2>
                <p className="text-sm text-slate-500">사업자 정보와 연락처를 정확히 입력해주세요.</p>
              </div>

              {result && (
                <div
                  className={`mx-6 mt-6 rounded-xl border p-4 ${
                    result.type === "SUCCESS"
                      ? "border-green-200 bg-green-50"
                      : "border-red-200 bg-red-50"
                  }`}
                >
                  <p className="font-medium">
                    {result.type === "SUCCESS" ? "성공" : "실패"} : {result.message}
                  </p>
                  {result?.data && (
                    <div className="text-sm text-slate-600 mt-2 space-y-1">
                      {result.data.token && (
                        <p>
                          토큰: <span className="break-all">{result.data.token}</span>
                        </p>
                      )}
                      {result.data.userId && <p>userId: {result.data.userId}</p>}
                      {result.data.role && <p>role: {result.data.role}</p>}
                    </div>
                  )}
                </div>
              )}

              <form onSubmit={handleSubmit} className="px-6 py-6 space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* name */}
                  <div>
                    <label className="flex items-center justify-between text-sm font-medium mb-2">
                      <span>가게명 *</span>
                      {errors.name && <span className="text-red-500">{errors.name}</span>}
                    </label>
                    <input
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      placeholder="예) 남탕가게"
                      aria-invalid={!!errors.name}
                      className={`w-full rounded-xl border px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100 ${
                        errors.name ? "border-red-400" : "border-slate-300"
                      }`}
                    />
                  </div>

                  {/* category */}
                  <div>
                    <label className="flex items-center justify-between text-sm font-medium mb-2">
                      <span>카테고리 *</span>
                      {errors.category && <span className="text-red-500">{errors.category}</span>}
                    </label>
                    <select
                      name="category"
                      value={form.category}
                      onChange={handleChange}
                      aria-invalid={!!errors.category}
                      className={`w-full rounded-xl border px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100 ${
                        errors.category ? "border-red-400" : "border-slate-300"
                      }`}
                    >
                      {categories.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>

                  {/* phone */}
                  <div>
                    <label className="flex items-center justify-between text-sm font-medium mb-2">
                      <span>연락처(휴대폰) *</span>
                      {errors.phone && <span className="text-red-500">{errors.phone}</span>}
                    </label>
                    <input
                      name="phone"
                      value={form.phone}
                      onChange={handleChange}
                      placeholder="010-1234-5678"
                      inputMode="numeric"
                      aria-invalid={!!errors.phone}
                      className={`w-full rounded-xl border px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100 ${
                        errors.phone ? "border-red-400" : "border-slate-300"
                      }`}
                    />
                    <p className="mt-1 text-xs text-slate-500">숫자만 입력해도 자동으로 하이픈이 들어가요.</p>
                  </div>

                  {/* address */}
                  <div>
                    <label className="flex items-center justify-between text-sm font-medium mb-2">
                      <span>주소 *</span>
                      {errors.address && <span className="text-red-500">{errors.address}</span>}
                    </label>
                    <input
                      name="address"
                      value={form.address}
                      onChange={handleChange}
                      placeholder="예) 서울특별시 중구 …"
                      aria-invalid={!!errors.address}
                      className={`w-full rounded-xl border px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100 ${
                        errors.address ? "border-red-400" : "border-slate-300"
                      }`}
                    />
                  </div>

                  {/* open / end time */}
                  <div>
                    <label className="flex items-center justify-between text-sm font-medium mb-2">
                      <span>오픈 시간 *</span>
                      {errors.opentime && <span className="text-red-500">{errors.opentime}</span>}
                    </label>
                    <input
                      type="time"
                      name="opentime"
                      value={form.opentime}
                      onChange={handleChange}
                      aria-invalid={!!errors.opentime}
                      className={`w-full rounded-xl border px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100 ${
                        errors.opentime ? "border-red-400" : "border-slate-300"
                      }`}
                    />
                  </div>

                  <div>
                    <label className="flex items-center justify-between text-sm font-medium mb-2">
                      <span>마감 시간 *</span>
                      {errors.endtime && <span className="text-red-500">{errors.endtime}</span>}
                    </label>
                    <input
                      type="time"
                      name="endtime"
                      value={form.endtime}
                      onChange={handleChange}
                      aria-invalid={!!errors.endtime}
                      className={`w-full rounded-xl border px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100 ${
                        errors.endtime ? "border-red-400" : "border-slate-300"
                      }`}
                    />
                  </div>
                </div>

                {/* actions */}
                <div className="flex items-center gap-3 pt-2">
                  <button
                    type="submit"
                    disabled={loading}
                    className="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 font-medium text-white shadow-sm transition hover:bg-blue-700 disabled:opacity-60"
                  >
                    {loading && (
                      <svg
                        className="h-4 w-4 animate-spin"
                        viewBox="0 0 24 24"
                        fill="none"
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                        />
                      </svg>
                    )}
                    {loading ? "등록 중…" : "가게 등록"}
                  </button>
                  <button
                    type="button"
                    onClick={handleReset}
                    className="rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-slate-700 hover:bg-slate-50"
                  >
                    초기화
                  </button>
                </div>

                {/* Dev notes */}
                <details className="mt-6 text-sm text-slate-600">
                  <summary className="cursor-pointer font-medium">개발 메모 (백엔드 연동)</summary>
                  <ul className="list-disc ml-5 mt-2 space-y-1">
                    <li>Vite 프록시 설정으로 CORS 문제가 자동으로 해결됩니다.</li>
                    <li>백엔드 API 엔드포인트: <code className="rounded bg-slate-100 px-1">POST /api/store/create</code></li>
                    <li>
                      Spring Boot CORS 권장: <code className="rounded bg-slate-100 px-1">@CrossOrigin(origins = "http://localhost:5173")</code>
                    </li>
                    <li>환경 변수로 API URL 관리: <code className="rounded bg-slate-100 px-1">VITE_API_BASE_URL</code></li>
                    <li>API 서비스 분리로 재사용성 향상</li>
                  </ul>
                </details>
              </form>
            </div>
          </section>

          {/* Live preview card */}
          <aside className="md:col-span-1">
            <div className="sticky top-20">
              <div className="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 overflow-hidden">
                <div className="px-5 py-4 border-b flex items-center justify-between">
                  <h3 className="font-semibold">미리보기</h3>
                  <span className="text-xs text-slate-500">영업 {openDuration}</span>
                </div>
                <div className="p-5">
                  <div className="rounded-xl border border-slate-200 p-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="text-lg font-semibold">{form.name || "가게명"}</h4>
                        <p className="text-sm text-slate-500 mt-0.5">{form.category}</p>
                      </div>
                      <div className="text-xs rounded-full bg-blue-50 text-blue-700 px-2 py-1">NEW</div>
                    </div>
                    <div className="mt-4 space-y-2 text-sm">
                      <p className="flex gap-2"><span className="shrink-0 text-slate-500">📍</span><span className="text-slate-700">{form.address || "주소"}</span></p>
                      <p className="flex gap-2"><span className="shrink-0 text-slate-500">📞</span><span className="text-slate-700">{form.phone || "010-0000-0000"}</span></p>
                      <p className="flex gap-2"><span className="shrink-0 text-slate-500">🕘</span><span className="text-slate-700">{form.opentime} ~ {form.endtime}</span></p>
                    </div>
                  </div>

                  {Object.keys(errors).length > 0 && (
                    <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3 text-sm text-amber-800">
                      입력값을 확인해주세요: {Object.values(errors).join(" · ")}
                    </div>
                  )}
                </div>
              </div>

              {/* 로고 등록 폼 */}
              <div className="mt-6 rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 overflow-hidden">
                <div className="px-5 py-4 border-b">
                  <h3 className="font-semibold">가게 로고</h3>
                  <p className="text-xs text-slate-500 mt-1">가게를 대표할 로고 이미지를 등록하세요.</p>
                </div>
                <div className="p-5">
                  {!logoPreview ? (
                    <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center hover:border-blue-400 transition-colors">
                      <div className="flex flex-col items-center">
                        <svg className="w-12 h-12 text-slate-400 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        <p className="text-sm font-medium text-slate-600 mb-2">로고 이미지 업로드</p>
                        <label className="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 transition-colors cursor-pointer">
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                          </svg>
                          파일 선택
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleLogoChange}
                            className="hidden"
                          />
                        </label>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="relative">
                        <img
                          src={logoPreview}
                          alt="로고 미리보기"
                          className="w-full h-32 object-contain bg-slate-50 rounded-xl border"
                        />
                        <button
                          type="button"
                          onClick={handleLogoRemove}
                          className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
                        >
                          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                        </button>
                      </div>
                      <div className="flex items-center justify-between text-sm text-slate-600">
                        <span>파일명: {logoFile?.name}</span>
                        <span>크기: {(logoFile?.size / 1024 / 1024).toFixed(2)}MB</span>
                      </div>
                      <label className="inline-flex items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        다른 이미지 선택
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleLogoChange}
                          className="hidden"
                        />
                      </label>
                    </div>
                  )}
                  
                  
                </div>
              </div>
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
}
