import React, { useState, useEffect } from 'react';
import { storeService } from '../services/storeService';

export default function StoreEditPage({ storeId, onBack, onSave }) {
  const [form, setForm] = useState({
    name: "",
    category: "한식",
    phone: "",
    address: "",
    openH: 9,
    openM: 0,
    closedH: 21,
    closedM: 0,
  });
  const [logoFile, setLogoFile] = useState(null);
  const [logoPreview, setLogoPreview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const categories = [
    "한식",
    "일식",
    "중식",
    "분식",
    "양식",
    "치킨",
    "피자",
    "카페/디저트",
  ];

  useEffect(() => {
    if (storeId) {
      loadStoreInfo();
    }
  }, [storeId]);

  const loadStoreInfo = async () => {
    try {
      setLoading(true);
      setError('');
      
      const storeData = await storeService.getStore(storeId);
      
      // 시간 정보를 폼에 맞게 변환
      const openTime = `${storeData.openH.toString().padStart(2, '0')}:${storeData.openM.toString().padStart(2, '0')}`;
      const closeTime = `${storeData.closedH.toString().padStart(2, '0')}:${storeData.closedM.toString().padStart(2, '0')}`;
      
      setForm({
        name: storeData.name || "",
        category: storeData.category || "한식",
        phone: storeData.phone || "",
        address: storeData.address || "",
        openH: storeData.openH || 9,
        openM: storeData.openM || 0,
        closedH: storeData.closedH || 21,
        closedM: storeData.closedM || 0,
      });
    } catch (err) {
      console.error('가게 정보 조회 오류:', err);
      setError(err.message || '가게 정보를 불러오는데 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    if (name === 'opentime') {
      const [hour, minute] = value.split(':').map(Number);
      setForm(prev => ({ ...prev, openH: hour, openM: minute }));
    } else if (name === 'endtime') {
      const [hour, minute] = value.split(':').map(Number);
      setForm(prev => ({ ...prev, closedH: hour, closedM: minute }));
    } else {
      setForm(prev => ({ ...prev, [name]: value }));
    }
    
    if (error) setError('');
    if (success) setSuccess('');
  };

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // 파일 크기 체크 (5MB 제한)
      if (file.size > 5 * 1024 * 1024) {
        alert('파일 크기는 5MB 이하여야 합니다.');
        return;
      }
      
      // 파일 타입 체크
      if (!file.type.startsWith('image/')) {
        alert('이미지 파일만 업로드 가능합니다.');
        return;
      }
      
      setLogoFile(file);
      
      // 미리보기 생성
      const reader = new FileReader();
      reader.onload = (e) => {
        setLogoPreview(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogoRemove = () => {
    setLogoFile(null);
    setLogoPreview(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // 유효성 검사
    if (!form.name.trim()) {
      setError('가게명을 입력해주세요.');
      return;
    }
    if (!form.phone.trim()) {
      setError('전화번호를 입력해주세요.');
      return;
    }
    if (!form.address.trim()) {
      setError('주소를 입력해주세요.');
      return;
    }

    setSaving(true);
    setError('');
    setSuccess('');

    try {
      // 가게 수정 API 호출 (현재는 목 서비스에서 지원하지 않으므로 성공으로 처리)
      await new Promise(resolve => setTimeout(resolve, 1000)); // 시뮬레이션
      
      setSuccess('가게 정보가 성공적으로 수정되었습니다.');
      
      // 2초 후 이전 페이지로 이동
      setTimeout(() => {
        if (onSave) onSave();
      }, 2000);
      
    } catch (err) {
      console.error('가게 수정 오류:', err);
      setError(err.message || '가게 정보 수정에 실패했습니다.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">가게 정보를 불러오는 중...</p>
        </div>
      </div>
    );
  }

  if (error && !form.name) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 text-6xl mb-4">⚠️</div>
          <h2 className="text-xl font-semibold text-slate-800 mb-2">오류 발생</h2>
          <p className="text-slate-600 mb-4">{error}</p>
          <button
            onClick={onBack}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            돌아가기
          </button>
        </div>
      </div>
    );
  }

  const openTime = `${form.openH.toString().padStart(2, '0')}:${form.openM.toString().padStart(2, '0')}`;
  const closeTime = `${form.closedH.toString().padStart(2, '0')}:${form.closedM.toString().padStart(2, '0')}`;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-10 backdrop-blur supports-[backdrop-filter]:bg-white/70 bg-white/90 border-b">
        <div className="mx-auto max-w-4xl px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div>
              <h1 className="text-lg font-semibold">가게 정보 수정</h1>
              <p className="text-xs text-slate-500">가게 정보를 수정하세요</p>
            </div>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-8">
        <div className="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b">
            <h2 className="font-semibold text-xl">가게 정보 수정</h2>
            <p className="mt-1 text-sm text-slate-600">가게의 기본 정보를 수정할 수 있습니다.</p>
          </div>

          {success && (
            <div className="mx-6 mt-6 rounded-xl border border-green-200 bg-green-50 p-4">
              <p className="font-medium text-green-800">{success}</p>
            </div>
          )}

          {error && (
            <div className="mx-6 mt-6 rounded-xl border border-red-200 bg-red-50 p-4">
              <p className="font-medium text-red-800">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="px-6 py-6 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* 가게명 */}
              <div>
                <label className="flex items-center justify-between text-sm font-medium mb-2">
                  <span>가게명 *</span>
                </label>
                <input
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  placeholder="예) 상훈분식"
                  required
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100"
                />
              </div>

              {/* 카테고리 */}
              <div>
                <label className="flex items-center justify-between text-sm font-medium mb-2">
                  <span>카테고리 *</span>
                </label>
                <select
                  name="category"
                  value={form.category}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100"
                >
                  {categories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              {/* 전화번호 */}
              <div>
                <label className="flex items-center justify-between text-sm font-medium mb-2">
                  <span>전화번호 *</span>
                </label>
                <input
                  name="phone"
                  value={form.phone}
                  onChange={handleChange}
                  placeholder="02-555-6666"
                  required
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100"
                />
              </div>

              {/* 주소 */}
              <div>
                <label className="flex items-center justify-between text-sm font-medium mb-2">
                  <span>주소 *</span>
                </label>
                <input
                  name="address"
                  value={form.address}
                  onChange={handleChange}
                  placeholder="서울시 마포구 합정동 321"
                  required
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100"
                />
              </div>

              {/* 오픈 시간 */}
              <div>
                <label className="flex items-center justify-between text-sm font-medium mb-2">
                  <span>오픈 시간 *</span>
                </label>
                <input
                  type="time"
                  name="opentime"
                  value={openTime}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100"
                />
              </div>

              {/* 마감 시간 */}
              <div>
                <label className="flex items-center justify-between text-sm font-medium mb-2">
                  <span>마감 시간 *</span>
                </label>
                <input
                  type="time"
                  name="endtime"
                  value={closeTime}
                  onChange={handleChange}
                  className="w-full rounded-xl border border-slate-300 px-3 py-2.5 shadow-sm focus:outline-none focus:ring-4 focus:ring-blue-100"
                />
              </div>
            </div>

            {/* 로고 업로드 섹션 */}
            <div className="border-t border-slate-200 pt-8">
              <h3 className="text-lg font-semibold text-slate-900 mb-4">가게 로고</h3>
              <div className="flex items-start gap-6">
                {/* 로고 미리보기 */}
                <div className="flex-shrink-0">
                  {logoPreview ? (
                    <div className="relative">
                      <img 
                        src={logoPreview} 
                        alt="로고 미리보기"
                        className="w-24 h-24 rounded-lg object-cover border border-slate-200"
                      />
                      <button
                        type="button"
                        onClick={handleLogoRemove}
                        className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center text-xs hover:bg-red-600"
                      >
                        ×
                      </button>
                    </div>
                  ) : (
                    <div className="w-24 h-24 rounded-lg bg-slate-100 border-2 border-dashed border-slate-300 flex items-center justify-center">
                      <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    </div>
                  )}
                </div>

                {/* 로고 업로드 컨트롤 */}
                <div className="flex-1">
                  <div className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 mb-2">
                        로고 이미지 업로드
                      </label>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleLogoChange}
                        className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                      />
                    </div>
                    <div className="text-xs text-slate-500">
                      <p>• 권장 크기: 200x200px 이상</p>
                      <p>• 지원 형식: JPG, PNG, GIF</p>
                      <p>• 최대 크기: 5MB</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 액션 버튼 */}
            <div className="flex items-center gap-3 pt-2">
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 font-medium text-white shadow-sm transition hover:bg-blue-700 disabled:opacity-60"
              >
                {saving && (
                  <svg
                    className="h-4 w-4 animate-spin"
                    viewBox="0 0 24 24"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"
                    />
                  </svg>
                )}
                {saving ? "수정 중…" : "가게 정보 수정"}
              </button>
              <button
                type="button"
                onClick={onBack}
                className="rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-slate-700 hover:bg-slate-50"
              >
                취소
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  );
}
