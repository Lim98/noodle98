import React, { useState, useEffect } from 'react';
import { storeService } from '../services/storeService';

export default function StoreManagePage({ onBack, onEdit }) {
  const [store, setStore] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadMyStore();
  }, []);

  const loadMyStore = async () => {
    try {
      setLoading(true);
      setError('');
      
      // 현재 사용자의 가게 목록을 가져와서 첫 번째 가게를 선택
      const stores = await storeService.getStores();
      
      if (stores && stores.length > 0) {
        // 첫 번째 가게를 선택
        const myStore = stores[0];
        setStore(myStore);
      } else {
        setStore(null);
      }
    } catch (err) {
      console.error('가게 정보 조회 오류:', err);
      setError(err.message || '가게 정보를 불러오는데 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  // 영업 시간 포맷팅
  const formatBusinessHours = (store) => {
    if (!store || store.openH === undefined || store.openM === undefined || 
        store.closedH === undefined || store.closedM === undefined) {
      return '영업시간 정보 없음';
    }
    
    const formatTime = (hour, minute) => {
      return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
    };
    
    const openTime = formatTime(store.openH, store.openM);
    const closeTime = formatTime(store.closedH, store.closedM);
    
    return `${openTime} - ${closeTime}`;
  };

  // 영업 상태 확인
  const isOpenNow = (store) => {
    if (!store || store.openH === undefined || store.openM === undefined || 
        store.closedH === undefined || store.closedM === undefined) {
      return false;
    }
    
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentTime = currentHour * 60 + currentMinute;
    
    const openTime = store.openH * 60 + store.openM;
    const closeTime = store.closedH * 60 + store.closedM;
    
    // 자정을 넘기는 경우 처리
    if (closeTime < openTime) {
      return currentTime >= openTime || currentTime <= closeTime;
    } else {
      return currentTime >= openTime && currentTime <= closeTime;
    }
  };

  // 가게 상태 스타일
  const getStoreStatus = (store) => {
    if (isOpenNow(store)) {
      return { text: '영업중', color: 'text-green-600', bg: 'bg-green-100', dot: 'bg-green-500' };
    } else {
      return { text: '영업종료', color: 'text-red-600', bg: 'bg-red-100', dot: 'bg-red-500' };
    }
  };

  // 생성일 포맷팅
  const formatCreatedAt = (store) => {
    if (!store || !store.createdAt) return '등록일 정보 없음';
    
    const date = new Date(store.createdAt);
    return date.toLocaleDateString('ko-KR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">가게 정보를 불러오는 중...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100 flex items-center justify-center">
        <div className="text-center">
          <div className="text-red-500 text-6xl mb-4">⚠️</div>
          <h2 className="text-xl font-semibold text-slate-800 mb-2">오류 발생</h2>
          <p className="text-slate-600 mb-4">{error}</p>
          <button
            onClick={onBack}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            돌아가기
          </button>
        </div>
      </div>
    );
  }

  if (!store) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
        <header className="sticky top-0 z-10 backdrop-blur supports-[backdrop-filter]:bg-white/70 bg-white/90 border-b">
          <div className="mx-auto max-w-4xl px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={onBack}
                className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
              <div>
                <h1 className="text-lg font-semibold">가게 관리</h1>
                <p className="text-xs text-slate-500">내 가게를 관리하세요</p>
              </div>
            </div>
          </div>
        </header>

        <main className="mx-auto max-w-4xl px-4 py-8">
          <div className="text-center py-12">
            <div className="text-slate-400 text-6xl mb-4">🏪</div>
            <h2 className="text-xl font-semibold text-slate-800 mb-2">등록된 가게가 없습니다</h2>
            <p className="text-slate-600 mb-6">먼저 가게를 등록해주세요.</p>
            <button
              onClick={() => window.location.href = '#store'}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              가게 등록하기
            </button>
          </div>
        </main>
      </div>
    );
  }

  const status = getStoreStatus(store);
  const businessHours = formatBusinessHours(store);
  const createdAt = formatCreatedAt(store);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 to-slate-100">
      {/* Header */}
      <header className="sticky top-0 z-10 backdrop-blur supports-[backdrop-filter]:bg-white/70 bg-white/90 border-b">
        <div className="mx-auto max-w-4xl px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={onBack}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
            <div>
              <h1 className="text-lg font-semibold">가게 관리</h1>
              <p className="text-xs text-slate-500">내 가게를 관리하세요</p>
            </div>
          </div>
          <div className={`px-3 py-1 rounded-full text-sm font-medium ${status.bg} ${status.color}`}>
            <div className={`w-2 h-2 ${status.dot} rounded-full inline-block mr-2`}></div>
            {status.text}
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* 가게 기본 정보 */}
          <div className="lg:col-span-2">
            <div className="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 overflow-hidden">
              <div className="px-6 py-4 border-b">
                <h2 className="font-semibold text-xl">{store.name}</h2>
                <p className="text-slate-500">{store.category}</p>
              </div>
              
              <div className="p-6 space-y-6">
                {/* 기본 정보 */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm font-medium text-slate-600 mb-2 block">가게명</label>
                    <p className="text-slate-800">{store.name}</p>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-slate-600 mb-2 block">카테고리</label>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {store.category}
                    </span>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-slate-600 mb-2 block">전화번호</label>
                    <p className="text-slate-800">{store.phone}</p>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-slate-600 mb-2 block">등록일</label>
                    <p className="text-slate-800">{createdAt}</p>
                  </div>
                </div>

                {/* 주소 */}
                <div>
                  <label className="text-sm font-medium text-slate-600 mb-2 block">주소</label>
                  <p className="text-slate-800">{store.address}</p>
                </div>

                {/* 영업시간 */}
                <div>
                  <label className="text-sm font-medium text-slate-600 mb-2 block">영업시간</label>
                  <p className="text-slate-800">{businessHours}</p>
                </div>

                {/* 수정 버튼 */}
                <div className="flex justify-end pt-4 border-t border-slate-200">
                  <button 
                    onClick={() => onEdit && onEdit(store.id)}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    가게 수정
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 사이드바 정보 */}
          <div className="space-y-6">
            {/* 가게 로고 카드 */}
            <div className="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 overflow-hidden">
              <div className="px-5 py-4 border-b">
                <h3 className="font-semibold">가게 로고</h3>
              </div>
              <div className="p-5">
                <div className="text-center">
                  {store.logoUrl ? (
                    <div className="mb-4">
                      <img 
                        src={store.logoUrl} 
                        alt={`${store.name} 로고`}
                        className="w-24 h-24 mx-auto rounded-lg object-cover border border-slate-200"
                      />
                      
                    </div>
                  ) : (
                    <div className="mb-4">
                      <div className="w-24 h-24 mx-auto rounded-lg bg-slate-100 border-2 border-dashed border-slate-300 flex items-center justify-center">
                        <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                      </div>
                      <p className="text-xs text-slate-500 mt-2">로고가 없습니다</p>
                    </div>
                  )}
                  
                </div>
              </div>
            </div>

            {/* 가게 통계 */}
            <div className="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 overflow-hidden">
              <div className="px-5 py-4 border-b">
                <h3 className="font-semibold">가게 정보</h3>
              </div>
              <div className="p-5 space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">가게 ID</span>
                  <span className="font-medium">{store.id}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">사장 ID</span>
                  <span className="font-medium">{store.memberId}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-600">등록일</span>
                  <span className="font-medium">{store.createdAt}</span>
                </div>
              </div>
            </div>

            {/* 액션 버튼들 */}
            <div className="rounded-2xl bg-white shadow-sm ring-1 ring-slate-200 overflow-hidden">
              <div className="px-5 py-4 border-b">
                <h3 className="font-semibold">관리</h3>
              </div>
              <div className="p-5">
                <button 
                  onClick={async () => {
                    if (confirm('정말로 이 가게를 삭제하시겠습니까?')) {
                      try {
                        await storeService.deleteStore(store.id);
                        alert('가게가 삭제되었습니다.');
                        onBack();
                      } catch (error) {
                        alert('가게 삭제에 실패했습니다.');
                      }
                    }
                  }}
                  className="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                >
                  가게 삭제
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
