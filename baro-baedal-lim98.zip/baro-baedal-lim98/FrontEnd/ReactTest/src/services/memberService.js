// API 서비스 - 회원 관련 API 호출을 담당
import { getAuthHeaders, handleAuthError } from '../utils/authUtils';
import { mockService } from './mockService';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '';

// 개발 모드에서는 목 서비스 사용
const isDevelopment = import.meta.env.DEV;
const useMockService = isDevelopment && (!API_BASE_URL || API_BASE_URL === '');

export const memberService = {
  // 회원가입
  async register(memberData) {
    if (useMockService) {
      return await mockService.register(memberData);
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/member/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(memberData),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('회원가입 API 오류:', error);
      throw error;
    }
  },

  // 로그인
  async login(loginData) {
    if (useMockService) {
      return await mockService.login(loginData);
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/member/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(loginData),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('로그인 API 오류:', error);
      throw error;
    }
  },

  // 로그아웃
  async logout() {
    if (useMockService) {
      return await mockService.logout();
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/member/logout`, {
        method: 'GET',
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('로그아웃 API 오류:', error);
      throw error;
    }
  },

  // 회원정보조회
  async getMyInfo() {
    if (useMockService) {
      return await mockService.getMyInfo();
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/member/info`, {
        method: 'GET',
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        if (handleAuthError(response)) {
          throw new Error('인증이 만료되었습니다. 다시 로그인해주세요.');
        }
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('내 정보 조회 API 오류:', error);
      throw error;
    }
  },

  // 회원정보변경
  async updateMyInfo(memberData) {
    if (useMockService) {
      return await mockService.updateMyInfo(memberData);
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/member/info`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(memberData),
      });

      if (!response.ok) {
        if (handleAuthError(response)) {
          throw new Error('인증이 만료되었습니다. 다시 로그인해주세요.');
        }
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('내 정보 수정 API 오류:', error);
      throw error;
    }
  }
};
