// menuService.js

export const menuService = {
    // 메뉴 삭제
    async deleteMenu(menuId) {
        try {
            const response = await fetch(`/api/menu/info/${menuId}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('메뉴 삭제 API 오류:', error);
            throw error;
        }
    },
    async createMenu(menuData) {
        try {
            const response = await fetch('/api/menu/create', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(menuData),
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('메뉴 등록 API 오류:', error);
            throw error;
        }
    },
    async updateMenu(menuId, updatedMenuData) {
        try {
            const response = await fetch(`/api/menu/info/${menuId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(updatedMenuData),
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            console.error('메뉴 수정 API 오류:', error);
            throw error;
        }
    },
};
