// 목(Mock) 데이터 서비스 - 백엔드 없이 테스트용
import { getAuthHeaders } from '../utils/authUtils';

// 목 데이터
const mockUsers = [
  {
    id: 1,
    userid: 'testuser',
    name: '테스트사용자',
    birth: '1990-01-01',
    phone: '010-1234-5678',
    email: 'test@example.com',
    address: '서울시 강남구 테헤란로 123',
    role: 'OWNER',
    created_at: '2024-01-01'
  },
  {
    id: 2,
    userid: 'admin',
    name: '관리자',
    birth: '1985-05-15',
    phone: '010-9876-5432',
    email: 'admin@example.com',
    address: '서울시 서초구 서초대로 456',
    role: 'ADMIN',
    created_at: '2024-01-15'
  }
];

const mockStores = [
  {
    id: 1,
    memberId: 1,
    category: '한식',
    name: '맛있는 김치찌개',
    address: '서울시 마포구 합정동 123-45',
    phone: '02-1234-5678',
    openH: 9,
    openM: 0,
    closedH: 21,
    closedM: 0,
    createdAt: '2024-01-20',
    logoUrl: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=200&h=200&fit=crop&crop=center'
  },
  {
    id: 2,
    memberId: 1,
    category: '중식',
    name: '왕만두',
    address: '서울시 강남구 역삼동 67-89',
    phone: '02-2345-6789',
    openH: 10,
    openM: 30,
    closedH: 22,
    closedM: 30,
    createdAt: '2024-01-25',
    logoUrl: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=200&h=200&fit=crop&crop=center'
  },
  {
    id: 3,
    memberId: 2,
    category: '일식',
    name: '스시마스터',
    address: '서울시 송파구 잠실동 101-202',
    phone: '02-3456-7890',
    openH: 11,
    openM: 0,
    closedH: 23,
    closedM: 0,
    createdAt: '2024-02-01',
    logoUrl: 'https://images.unsplash.com/photo-1579584425555-c3ce17fd4351?w=200&h=200&fit=crop&crop=center'
  }
];

// 로그인된 사용자 정보 (localStorage에서 관리)
let currentUser = null;

// 지연 시뮬레이션 (실제 API 호출과 유사한 경험)
const delay = (ms = 1000) => new Promise(resolve => setTimeout(resolve, ms));

export const mockService = {
  // 로그인
  async login(credentials) {
    await delay(800);
    
    const user = mockUsers.find(u => 
      u.userid === credentials.userid && 
      u.phone === credentials.userpw // 간단한 테스트를 위해 전화번호를 비밀번호로 사용
    );
    
    if (user) {
      const token = `mock_token_${user.id}_${Date.now()}`;
      currentUser = { ...user, token };
      
      // localStorage에 저장
      localStorage.setItem('token', token);
      localStorage.setItem('userid', user.userid);
      localStorage.setItem('role', user.role);
      
      return {
        responseType: 'SUCCESS',
        message: '로그인 성공',
        data: {
          token,
          userId: user.id,
          role: user.role,
          userid: user.userid
        }
      };
    } else {
      return {
        responseType: 'FAIL',
        message: '아이디 또는 비밀번호가 올바르지 않습니다.'
      };
    }
  },

  // 회원가입
  async register(userData) {
    await delay(1200);
    
    // 간단한 유효성 검사
    if (!userData.userid || !userData.userpw || !userData.name) {
      return {
        responseType: 'FAIL',
        message: '필수 정보를 모두 입력해주세요.'
      };
    }
    
    // 중복 아이디 체크
    const existingUser = mockUsers.find(u => u.userid === userData.userid);
    if (existingUser) {
      return {
        responseType: 'FAIL',
        message: '이미 존재하는 아이디입니다.'
      };
    }
    
    // 새 사용자 생성
    const newUser = {
      id: mockUsers.length + 1,
      userid: userData.userid,
      name: userData.name,
      birth: userData.birth || '',
      phone: userData.phone || '',
      email: userData.email || '',
      address: userData.address || '',
      role: 'MEMBER',
      created_at: new Date().toISOString().split('T')[0]
    };
    
    mockUsers.push(newUser);
    
    return {
      responseType: 'SUCCESS',
      message: '회원가입이 완료되었습니다.',
      data: newUser
    };
  },

  // 내 정보 조회
  async getMyInfo() {
    await delay(500);
    
    const token = localStorage.getItem('token');
    if (!token || !currentUser) {
      return {
        responseType: 'FAIL',
        message: '로그인이 필요합니다.'
      };
    }
    
    return {
      responseType: 'SUCCESS',
      data: currentUser
    };
  },

  // 내 정보 수정
  async updateMyInfo(userData) {
    await delay(800);
    
    if (!currentUser) {
      return {
        responseType: 'FAIL',
        message: '로그인이 필요합니다.'
      };
    }
    
    // 사용자 정보 업데이트
    const updatedUser = { ...currentUser, ...userData };
    currentUser = updatedUser;
    
    // mockUsers 배열도 업데이트
    const userIndex = mockUsers.findIndex(u => u.id === currentUser.id);
    if (userIndex !== -1) {
      mockUsers[userIndex] = { ...mockUsers[userIndex], ...userData };
    }
    
    return {
      responseType: 'SUCCESS',
      message: '회원정보가 수정되었습니다.',
      data: updatedUser
    };
  },

  // 로그아웃
  async logout() {
    await delay(300);
    
    currentUser = null;
    localStorage.removeItem('token');
    localStorage.removeItem('userid');
    localStorage.removeItem('role');
    
    return {
      responseType: 'SUCCESS',
      message: '로그아웃되었습니다.'
    };
  },

  // 가게 등록
  async createStore(storeData) {
    await delay(1000);
    
    if (!currentUser) {
      return {
        responseType: 'FAIL',
        message: '로그인이 필요합니다.'
      };
    }
    
    const newStore = {
      id: mockStores.length + 1,
      memberId: currentUser.id,
      category: storeData.category,
      name: storeData.name,
      address: storeData.address,
      phone: storeData.phone,
      openH: storeData.openH,
      openM: storeData.openM,
      closedH: storeData.closedH,
      closedM: storeData.closedM,
      createdAt: storeData.createdAt
    };
    
    mockStores.push(newStore);
    
    return {
      responseType: 'SUCCESS',
      message: '가게가 성공적으로 등록되었습니다.',
      data: newStore
    };
  },

  // 가게 목록 조회
  async getStores() {
    await delay(600);
    
    if (!currentUser) {
      return {
        responseType: 'FAIL',
        message: '로그인이 필요합니다.'
      };
    }
    
    // 현재 사용자의 가게만 반환
    const userStores = mockStores.filter(store => store.memberId === currentUser.id);
    
    return userStores;
  },

  // 가게 상세 조회
  async getStore(storeId) {
    await delay(400);
    
    if (!currentUser) {
      return {
        responseType: 'FAIL',
        message: '로그인이 필요합니다.'
      };
    }
    
    const store = mockStores.find(s => s.id === parseInt(storeId));
    
    if (!store) {
      return {
        responseType: 'FAIL',
        message: '가게를 찾을 수 없습니다.'
      };
    }
    
    // 권한 체크 (본인의 가게만 조회 가능)
    if (store.memberId !== currentUser.id) {
      return {
        responseType: 'FAIL',
        message: '권한이 없습니다.'
      };
    }
    
    return store;
  },

  // 가게 삭제
  async deleteStore(storeId) {
    await delay(700);
    
    if (!currentUser) {
      return {
        responseType: 'FAIL',
        message: '로그인이 필요합니다.'
      };
    }
    
    const storeIndex = mockStores.findIndex(s => s.id === parseInt(storeId));
    
    if (storeIndex === -1) {
      return {
        responseType: 'FAIL',
        message: '가게를 찾을 수 없습니다.'
      };
    }
    
    const store = mockStores[storeIndex];
    
    // 권한 체크
    if (store.memberId !== currentUser.id) {
      return {
        responseType: 'FAIL',
        message: '권한이 없습니다.'
      };
    }
    
    mockStores.splice(storeIndex, 1);
    
    return {
      responseType: 'SUCCESS',
      message: '가게가 삭제되었습니다.'
    };
  },

  // 목 데이터 초기화 (개발용)
  resetMockData() {
    currentUser = null;
    localStorage.clear();
    console.log('목 데이터가 초기화되었습니다.');
  },

  // 현재 목 데이터 상태 확인 (개발용)
  getMockDataStatus() {
    return {
      currentUser,
      totalUsers: mockUsers.length,
      totalStores: mockStores.length,
      userStores: currentUser ? mockStores.filter(s => s.memberId === currentUser.id) : []
    };
  }
};
