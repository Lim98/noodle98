// API 서비스 - 가게 관련 API 호출을 담당
import { getAuthHeaders, handleAuthError } from '../utils/authUtils';
import { mockService } from './mockService';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '';

// 개발 모드에서는 목 서비스 사용
const isDevelopment = import.meta.env.DEV;
const useMockService = isDevelopment && (!API_BASE_URL || API_BASE_URL === '');

export const storeService = {
  // 가게 등록
  async createStore(storeData) {
    if (useMockService) {
      return await mockService.createStore(storeData);
    }
    
    try {
      // API 요청 데이터 구조 변환
      const requestData = {
        category: storeData.category,
        name: storeData.name,
        address: storeData.address,
        phone: storeData.phone,
        openH: storeData.openH,
        openM: storeData.openM,
        closedH: storeData.closedH,
        closedM: storeData.closedM,
        createdAt: storeData.createdAt
      };

      const response = await fetch(`${API_BASE_URL}/api/store/create`, {
        method: 'POST',
        headers: getAuthHeaders(),
        body: JSON.stringify(requestData),
      });

      if (!response.ok) {
        if (handleAuthError(response)) {
          throw new Error('인증이 만료되었습니다. 다시 로그인해주세요.');
        }
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('가게 등록 API 오류:', error);
      throw error;
    }
  },

  // 가게 목록 조회
  async getStores() {
    if (useMockService) {
      return await mockService.getStores();
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/store/list`, {
        method: 'GET',
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        if (handleAuthError(response)) {
          throw new Error('인증이 만료되었습니다. 다시 로그인해주세요.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('가게 목록 조회 API 오류:', error);
      throw error;
    }
  },

  // 가게 상세 조회
  async getStore(storeId) {
    if (useMockService) {
      return await mockService.getStore(storeId);
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/store/${storeId}`, {
        method: 'GET',
        headers: getAuthHeaders(),
      });

      if (!response.ok) {
        if (handleAuthError(response)) {
          throw new Error('인증이 만료되었습니다. 다시 로그인해주세요.');
        }
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('가게 상세 조회 API 오류:', error);
      throw error;
    }
  },
  async deleteStore(storeId) {
    if (useMockService) {
      return await mockService.deleteStore(storeId);
    }
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/store/info/${storeId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json',
        },
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.message || `HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('가게 삭제 API 오류:', error);
      throw error;
    }
  },
};

