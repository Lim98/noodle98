// 인증 관련 유틸리티 함수들

/**
 * 인증 헤더를 생성합니다.
 * 토큰이 있으면 Bearer Token을 포함한 헤더를 반환합니다.
 */
export const getAuthHeaders = () => {
  const token = localStorage.getItem('token');
  
  const headers = {
    'Content-Type': 'application/json',
  };
  
  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }
  
  return headers;
};

/**
 * 현재 로그인 상태를 확인합니다.
 */
export const isLoggedIn = () => {
  const token = localStorage.getItem('token');
  return !!token;
};

/**
 * 로그인 정보를 가져옵니다.
 */
export const getAuthInfo = () => {
  return {
    token: localStorage.getItem('token'),
    userid: localStorage.getItem('userid'),
    role: localStorage.getItem('role')
  };
};

/**
 * 로그인 정보를 저장합니다.
 */
export const setAuthInfo = (authData) => {
  localStorage.setItem('token', authData.token);
  localStorage.setItem('userid', authData.userld);
  localStorage.setItem('role', authData.role);
};

/**
 * 로그아웃 처리 (토큰 및 사용자 정보 삭제)
 */
export const clearAuthInfo = () => {
  localStorage.removeItem('token');
  localStorage.removeItem('userid');
  localStorage.removeItem('role');
};

/**
 * API 응답에서 401 (Unauthorized) 에러 처리
 * 토큰이 만료되었거나 유효하지 않을 때 로그아웃 처리
 */
export const handleAuthError = (response) => {
  if (response.status === 401) {
    clearAuthInfo();
    // 로그인 페이지로 리다이렉트하거나 상태 업데이트
    window.location.reload();
    return true;
  }
  return false;
};
