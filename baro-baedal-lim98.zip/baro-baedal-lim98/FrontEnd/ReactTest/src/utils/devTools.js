// 개발자 도구 - 목 데이터 관리 및 디버깅
import { mockService } from '../services/mockService';

// 개발자 도구를 전역으로 등록
if (import.meta.env.DEV) {
  window.devTools = {
    // 목 데이터 상태 확인
    getMockDataStatus: () => {
      const status = mockService.getMockDataStatus();
      console.log('📊 목 데이터 상태:', status);
      return status;
    },
    
    // 목 데이터 초기화
    resetMockData: () => {
      mockService.resetMockData();
      console.log('🔄 목 데이터가 초기화되었습니다.');
      window.location.reload();
    },
    
    // 테스트 계정으로 로그인
    loginAsTestUser: () => {
      const testCredentials = {
        userid: 'testuser',
        userpw: '010-1234-5678' // 전화번호를 비밀번호로 사용
      };
      console.log('🔑 테스트 계정으로 로그인 시도:', testCredentials);
      return testCredentials;
    },
    
    // 관리자 계정으로 로그인
    loginAsAdmin: () => {
      const adminCredentials = {
        userid: 'admin',
        userpw: '010-9876-5432'
      };
      console.log('👑 관리자 계정으로 로그인 시도:', adminCredentials);
      return adminCredentials;
    },
    
    // 현재 로그인 상태 확인
    checkAuthStatus: () => {
      const token = localStorage.getItem('token');
      const userid = localStorage.getItem('userid');
      const role = localStorage.getItem('role');
      
      console.log('🔐 현재 인증 상태:', {
        isLoggedIn: !!token,
        userid,
        role,
        token: token ? `${token.substring(0, 20)}...` : null
      });
      
      return { token, userid, role };
    },
    
    // 로그아웃
    logout: () => {
      localStorage.clear();
      console.log('🚪 로그아웃되었습니다.');
      window.location.reload();
    },
    
    // 도움말
    help: () => {
      console.log(`
🛠️ 개발자 도구 사용법:

1. 목 데이터 상태 확인:
   devTools.getMockDataStatus()

2. 목 데이터 초기화:
   devTools.resetMockData()

3. 테스트 계정으로 로그인:
   - 아이디: testuser
   - 비밀번호: 010-1234-5678

4. 관리자 계정으로 로그인:
   - 아이디: admin  
   - 비밀번호: 010-9876-5432

5. 현재 로그인 상태 확인:
   devTools.checkAuthStatus()

6. 로그아웃:
   devTools.logout()

7. 도움말:
   devTools.help()
      `);
    }
  };
  
  // 콘솔에 도움말 표시
  console.log(`
🎯 바로배달 개발자 도구가 활성화되었습니다!

사용 가능한 명령어:
- devTools.help() : 도움말 보기
- devTools.getMockDataStatus() : 목 데이터 상태 확인
- devTools.loginAsTestUser() : 테스트 계정 정보 확인
- devTools.checkAuthStatus() : 현재 로그인 상태 확인

테스트 계정:
- 일반 사용자: testuser / 010-1234-5678
- 관리자: admin / 010-9876-5432
  `);
}
