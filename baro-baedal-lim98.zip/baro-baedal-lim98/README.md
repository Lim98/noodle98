# 바로배달 (baro-baedal)

사장님을 위한 배달 주문 관리 시스템. Spring Boot 백엔드와 Next.js 프론트엔드로 구성된 풀스택 웹 애플리케이션입니다.

## 🚀 주요 기능

### 📊 대시보드
- 실시간 주문 현황 모니터링
- 매출 통계 및 분석
- 주문 관리 및 처리

### 🏪 가게 관리
- 가게 정보 등록 및 수정
- 운영 시간 설정
- 로고 업로드

### 🍽️ 메뉴 관리
- 메뉴 추가, 수정, 삭제
- 가격 및 설명 관리
- 썸네일 이미지 업로드

### 💰 매출 관리
- 기간별 매출 분석
- 일별/주별/월별 통계
- 주문 현황 추적

## 🛠️ 기술 스택

### Backend
- **Spring Boot** 3.x
- **Java** 17+
- **Gradle** 빌드 도구
- **JWT** 인증
- **MySQL** 데이터베이스

### Frontend
- **Next.js** 15.5.6
- **React** 19.2.0
- **TypeScript**
- **Tailwind CSS**
- **Radix UI** 컴포넌트
- **Framer Motion** 애니메이션

## 📁 프로젝트 구조

```
baro-baedal/
├── Backend/                 # Spring Boot 백엔드
│   ├── src/main/java/      # Java 소스 코드
│   ├── src/main/resources/ # 설정 파일
│   └── build.gradle        # Gradle 설정
├── FrontEnd/               # Next.js 프론트엔드
│   └── NextJsTest/         # 메인 프론트엔드 앱
│       ├── app/            # Next.js App Router
│       ├── components/     # React 컴포넌트
│       ├── lib/           # 유틸리티 함수
│       └── public/        # 정적 파일
└── Mobile/                 # 모바일 앱 (향후 개발)
```

## 🚀 시작하기

### 필수 요구사항
- **Java** 17 이상
- **Node.js** 18 이상
- **npm** 또는 **yarn**
- **MySQL** 8.0 이상

### 1. 백엔드 실행

```bash
# Backend 디렉터리로 이동
cd Backend

# Gradle Wrapper 권한 설정 (Linux/Mac)
chmod +x gradlew

# 의존성 설치 및 실행
./gradlew bootRun
# 또는 Windows에서
gradlew.bat bootRun
```

백엔드 서버가 `http://localhost:8080`에서 실행됩니다.

### 2. 프론트엔드 실행

```bash
# FrontEnd/NextJsTest 디렉터리로 이동
cd FrontEnd/NextJsTest

# 의존성 설치
npm install
# 또는
yarn install

# 개발 서버 실행
npm run dev
# 또는
yarn dev
```

프론트엔드가 `http://localhost:3000`에서 실행됩니다.

## 🔧 설정

### 백엔드 설정
`Backend/src/main/resources/application.yml`에서 데이터베이스 연결 정보를 수정하세요:

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/your_database
    username: your_username
    password: your_password
```

### 프론트엔드 설정
`FrontEnd/NextJsTest/lib/api-client.ts`에서 API 기본 URL을 확인하세요:

```typescript
const API_BASE_URL = "http://localhost:8080"
```

## 📱 주요 페이지

- **로그인** (`/login`) - 사장님 로그인
- **대시보드** (`/dashboard`) - 주문 현황 대시보드
- **가게 관리** (`/store`) - 가게 정보 관리
- **메뉴 관리** (`/menu`) - 메뉴 추가/수정/삭제
- **매출 관리** (`/revenue`) - 매출 분석 및 통계
- **마이페이지** (`/myinfo`) - 회원 정보 관리

## 🔐 인증 시스템

- JWT 토큰 기반 인증
- 자동 토큰 만료 처리
- 세션 만료 시 자동 로그아웃

## 🎨 UI/UX 특징

- **다크 테마** 사이드바
- **반응형** 디자인
- **애니메이션** 효과
- **토스트** 알림 시스템
- **모달** 기반 상호작용

## 🧪 테스트

### 백엔드 테스트
```bash
cd Backend
./gradlew test
```

### 프론트엔드 테스트
```bash
cd FrontEnd/NextJsTest
npm run lint
```

## 📦 빌드 및 배포

### 백엔드 빌드
```bash
cd Backend
./gradlew build
```

### 프론트엔드 빌드
```bash
cd FrontEnd/NextJsTest
npm run build
```

## 🤝 기여하기

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 라이선스

이 프로젝트는 MIT 라이선스 하에 있습니다.

## 📞 지원

문제가 발생하거나 질문이 있으시면 이슈를 생성해주세요.

---

**바로배달** - 가장 빠르고 안전한 배달 서비스 🚚