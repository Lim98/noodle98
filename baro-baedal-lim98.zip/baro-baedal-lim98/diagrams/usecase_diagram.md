# 바로배달 유스케이스 다이어그램

## 유스케이스 다이어그램

```mermaid
graph TB
    %% 액터 정의
    Customer[일반 사용자]
    Owner[가게 주인 OWNER]
    Admin[관리자 ADMIN]
    
    subgraph "사용자 인증 및 회원 관리"
        UC1[회원가입]
        UC2[로그인]
        UC3[로그아웃]
        UC4[회원정보 조회]
        UC5[회원정보 수정]
    end
    
    subgraph "포인트 시스템"
        UC6[포인트 조회]
        UC7[포인트 충전]
    end
    
    subgraph "가게 관리"
        UC8[가게 등록]
        UC9[가게 정보 조회]
        UC10[가게 정보 수정]
        UC11[가게 검색]
        UC12[가게 삭제]
    end
    
    subgraph "메뉴 관리"
        UC13[메뉴 등록]
        UC14[메뉴 조회]
        UC15[메뉴 수정]
        UC16[메뉴 삭제]
    end
    
    subgraph "주문 관리"
        UC17[주문 생성]
        UC18[주문 조회]
        UC19[주문 수정]
        UC20[주문 삭제]
        UC21[기간별 주문 조회]
    end
    
    subgraph "정산 및 통계"
        UC22[매출 통계 조회]
        UC23[정산 관리]
    end
    
    subgraph "파일 관리"
        UC24[이미지 업로드]
    end
    
    %% 일반 사용자
    Customer --> UC1
    Customer --> UC2
    Customer --> UC3
    Customer --> UC4
    Customer --> UC5
    Customer --> UC6
    Customer --> UC7
    Customer --> UC9
    Customer --> UC11
    Customer --> UC14
    Customer --> UC17
    Customer --> UC18
    
    %% 가게 주인
    Owner --> UC2
    Owner --> UC3
    Owner --> UC4
    Owner --> UC5
    Owner --> UC8
    Owner --> UC9
    Owner --> UC10
    Owner --> UC13
    Owner --> UC14
    Owner --> UC15
    Owner --> UC16
    Owner --> UC18
    Owner --> UC21
    Owner --> UC22
    Owner --> UC24
    
    %% 관리자
    Admin --> UC2
    Admin --> UC3
    Admin --> UC12
    Admin --> UC18
    Admin --> UC23
    
    style Customer fill:#e1f5ff
    style Owner fill:#fff4e1
    style Admin fill:#ffe1e1
```

## 상세 유스케이스 설명

### 사용자 인증 및 회원 관리
- **회원가입**: 사용자 정보(아이디, 비밀번호, 이름, 생년월일, 전화번호, 이메일, 주소) 입력
- **로그인**: JWT 토큰 발급 (1시간 유효)
- **로그아웃**: 클라이언트 측 토큰 삭제
- **회원정보 조회**: 본인 정보 확인
- **회원정보 수정**: 프로필 정보 업데이트

### 포인트 시스템
- **포인트 조회**: 현재 보유 포인트 확인
- **포인트 충전**: 포인트 추가 (사용자 직접 조작 가능 - 보안 취약점!)

### 가게 관리
- **가게 등록**: OWNER 권한 필요, 카테고리, 이름, 주소, 전화번호, 운영시간, 썸네일 등록
- **가게 정보 조회**: 모든 사용자 가능
- **가게 정보 수정**: OWNER 권한 필요, 본인 가게만 수정 가능
- **가게 검색**: 가게명으로 검색
- **가게 삭제**: ADMIN 권한 필요

### 메뉴 관리
- **메뉴 등록**: OWNER 권한, 본인 가게에만 등록
- **메뉴 조회**: 모든 사용자 가능
- **메뉴 수정**: OWNER 권한, 본인 메뉴만 수정
- **메뉴 삭제**: OWNER 권한, 본인 메뉴만 삭제

### 주문 관리
- **주문 생성**: 메뉴 선택, 수량 입력, 자동 가격 계산
- **주문 조회**: 본인 주문 또는 가게 주문 조회
- **주문 수정**: 주문 정보 변경
- **주문 삭제**: 주문 취소
- **기간별 주문 조회**: 날짜 범위로 주문 조회

### 정산 및 통계
- **매출 통계 조회**: OWNER 본인 가게 매출 확인
- **정산 관리**: ADMIN 권한

### 파일 관리
- **이미지 업로드**: 가게 썸네일, 메뉴 이미지 업로드 (최대 10MB)
